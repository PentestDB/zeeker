function main()
{
  locate();
}
